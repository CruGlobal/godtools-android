package com.example.rmatt.crureader.bo.GPage.RenderHelpers;

/**
 * Created by rmatt on 11/16/2016.
 */

public class RenderIntents {


}
