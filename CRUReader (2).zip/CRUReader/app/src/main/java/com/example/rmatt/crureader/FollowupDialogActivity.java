package com.example.rmatt.crureader;

import android.app.Activity;

/**
 * Created by rmatt on 11/23/2016.
 */

public class FollowupDialogActivity extends Activity {
}
