package com.example.rmatt.crureader.bo.GPage;

import android.content.Context;
import android.support.percent.PercentRelativeLayout;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

import static android.content.ContentValues.TAG;

/**
 * Created by rmatt on 10/25/2016.
 */
@Root(name="button-pair")
public class GButtonPair extends GBaseAttributes {


    @Element(name="positive-button", required = false)
    public GSimpleButton positiveButton;

    @Element(name="negative-button", required = false)
    public GSimpleButton negativeButton;

    @Override
    public LinearLayout render(ViewGroup viewGroup) {
        Context context = viewGroup.getContext();
        LinearLayout ll = new LinearLayout(context);
        ll.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        ll.setOrientation(LinearLayout.HORIZONTAL);

        ll.addView(negativeButton.render(viewGroup), new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        ll.addView(positiveButton.render(viewGroup), new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return ll;
    }
}
