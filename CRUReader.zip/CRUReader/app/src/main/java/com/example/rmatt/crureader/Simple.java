package com.example.rmatt.crureader;

/**
 * Created by rmatt on 10/18/2016.
 */

public class Simple {
    @Override
    public String toString() {
        return "Simple{" +
                "x=" + x +
                ", y=" + y +
                '}';
    }

    public int x = 1;
    public int y = 2;
}
