package com.example.rmatt.crureader.bo.GPage.RenderHelpers;

import android.content.Context;
import android.util.SparseArray;

import com.example.rmatt.crureader.RenderApp;
import com.example.rmatt.crureader.bo.GPage.GPanel;
import com.example.rmatt.crureader.bo.Gtapi;

import java.util.HashMap;

/**
 * Created by rmatt on 11/16/2016.
 */

public class RenderSingleton {


    private Context context;

    public SparseArray<Gtapi> gPanelHashMap = new SparseArray<Gtapi>();
    public String globalColor;

    private static RenderSingleton renderSingleton;

    private RenderSingleton(Context context) {
        this.context = context;
    }

    public static RenderSingleton getInstance() {
        return renderSingleton;
    }

    public static RenderSingleton init(Context context) {
        if (renderSingleton == null) {
            renderSingleton = new RenderSingleton(context);
        }
        return renderSingleton;
    }
}
