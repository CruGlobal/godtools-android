package com.example.rmatt.crureader.bo.GPage;

import android.content.Context;
import android.support.percent.PercentRelativeLayout;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.rmatt.crureader.bo.GPage.IDO.IRender;
import com.example.rmatt.crureader.bo.GPage.RenderHelpers.RenderConstants;
import com.example.rmatt.crureader.bo.Gtapi;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Root;
import org.simpleframework.xml.Text;

/**
 * Created by rmatt on 10/25/2016.
 */

public abstract class GBaseButtonAttributes extends GBaseAttributes implements IRender {




    private static final String TAG = "GBaseButtonAttributes";
    @Attribute(required = false)
    public String validation;

    @Attribute(required = false)
    public String mode;


    @Attribute(name = "tap-events", required = false)
    public String tapEvents;





}
